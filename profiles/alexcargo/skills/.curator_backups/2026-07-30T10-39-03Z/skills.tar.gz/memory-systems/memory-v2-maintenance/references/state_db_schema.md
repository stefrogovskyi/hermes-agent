# state.db schema notes for memory_v2 extraction

Relevant tables live in `C:/Users/Stefan/AppData/Local/hermes/state.db`.

## sessions columns (selected)
- `id` — session key (string, e.g. `cron_...`).
- `source` — `cron`, `telegram`, `tui`, `desktop`, etc.
- `display_name`, `title`
- `started_at`, `ended_at` — **float unix timestamps** (no `created_at` exists).
- `message_count`, `tool_call_count`
- `ended_at` is NULL for still-active sessions.

## messages columns (selected)
- `id`, `session_id`
- `role` — `user`, `assistant`, `tool`, `system`
- `content` — raw string payload (often JSON for tool results)
- `tool_name`, `tool_calls`
- `timestamp` — float unix timestamp
- `platform_message_id`
- `finish_reason`

## Common pitfall
Queries often fail with `sqlite3.OperationalError: no such column: created_at` because
Symptom → hypothesis → root cause → fix → reflection the helper assumes an ISO-string
column. The correct way is `WHERE started_at >= <float_cutoff>`.

## Last-24h cutoff Python snippet
```python
from datetime import datetime, timedelta
now = datetime.now()
cutoff = now - timedelta(hours=24)
cutoff_ts = cutoff.timestamp()  # float
```

## Session selection heuristics
- Include: sessions where `started_at >= cutoff_ts` or `ended_at >= cutoff_ts`.
- Filter: skip `message_count is None or < 2`.
- High-signal: sessions with large `tool_call_count` or non-trivial titles.
