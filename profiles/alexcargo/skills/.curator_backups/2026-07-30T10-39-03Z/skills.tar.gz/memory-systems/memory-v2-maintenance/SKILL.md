---
name: memory-v2-maintenance
description: 'Maintain Hermes memory_v2: harvest, cases, sync.'
---

# Memory v2 Maintenance (hermes memory_v2)

Hermes long-term memory filesystem at `C:/Users/Stefan/AppData/Local/hermes/memory_v2/`.
It is NOT the 2200-char `memory` tool — that one is only a pointer. memory_v2 holds
full case files (symptom → hypothesis → root cause → fix → reflection), principles, and
domain notes, plus a Pinecone semantic index.

## When to use
- Scheduled cron memory steward (default: 02:00 harvest / 03:00 Pinecone sync).
- After a non-trivial incident is resolved and the session produced durable lessons.
- When you detect a prior session crash, state.db write error, or truncated turn.
- Stefan asks to log a case or remember a rule.

## Layout
- `C:/Users/Stefan/AppData/Local/hermes/memory_v2/`
  - `recall.py` — keyword search helper.
  - `pinecone_query.py` — semantic search helper.
  - `pinecone_sync.py` — re-index chunks to Pinecone.
  - `add_case.py` — scaffold a new case + update `index.md`.
  - `memory_harvest.py` — extract candidates (INSTRUCTION / SUCCESS / METHOD) from a session text.
  - `index.md` — case/domain table.
  - `cases/` — `.md` case files.
  - `principles/` — durable rules.
  - `domains/life_domains.md` — domain-tagged notes.

## Harvest workflow (24h extraction → classify → record)

### 1. Extract transcript from state.db
- `C:/Users/Stefan/AppData/Local/hermes/state.db` holds all session messages in `messages` table.
- `sessions` table time columns: `started_at`, `ended_at` — both are **float unix timestamps**; `created_at` does NOT exist.
- Query for last-24h sessions:
  ```sql
  SELECT id, display_name, title, started_at, ended_at, message_count, source
  FROM sessions
  WHERE started_at >= <cutoff_ts> OR ended_at >= <cutoff_ts>
  ORDER BY COALESCE(ended_at, started_at) DESC
  ```
- Dump messages for interesting sessions:
  ```sql
  SELECT role, content, tool_name, timestamp, platform_message_id
  FROM messages
  WHERE session_id = ?
  ORDER BY timestamp ASC
  ```
- Skip pure-cron heartbeat sessions unless they carry instruction-level content.
- Write clean transcript to a temp `.txt` file before harvester.

### 2. Run harvester
```bash
cd "C:/Users/Stefan/AppData/Local/hermes/memory_v2"
"C:/Users/Stefan/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe" memory_harvest.py <transcript_file>
```

### 3. Classify and record candidates
For each candidate (`INSTRUCTION` / `SUCCESS` / `METHOD`) with a domain tag:
- **Verify the suggested domain** — the tagger is heuristic; accept only if correct.
  Valid: `agent_club` / `ai_infra` / `memory_systems` / `business` / `personal` / `new:<name>`.
- **INSTRUCTION / durable rule from Stefan**:
  - New rule → append to `principles/<slug>.md` or `domains/life_domains.md`.
  - Duplicate → update existing file; do not branch.
- **SUCCESS / METHOD**:
  - New case: `C:/Users/Stefan/AppData/Local/hermes/memory_v2/cases/<YYYY-MM-DD_<slug>>.md`
    via `add_case.py <slug> "<desc>" "<lesson>"`.
  - Update existing case: append a dated section directly with `patch` / `write_file`
    because `add_case.py` refuses overwrite.
  - Update `index.md` with the new row in the cases table.
- Cross-link cases to domain notes when they touch pricing, architecture, or bot behavior.

### 4. Re-index
```bash
cd "C:/Users/Stefan/AppData/Local/hermes/memory_v2"
"C:/Users/Stefan/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe" pinecone_sync.py
```

## Critical pitfall: false positives from raw tool transcripts
`memory_harvest.py` is a keyword matcher. Feeding it raw tool output causes false
"INSTRUCTION" / "METHOD" candidates from internal plumbing (script sources, JSON
tool dumps, diagnostic reads). **Mitigation:** clean the transcript first — preserve
only `user` and `assistant` lines, or strip tool JSON blocks. Re-reading existing
memory files does NOT generate new facts.

## Cron caveats
- Cron sessions may **not** support `notify_on_complete` / `watch_patterns`.
  Use `process(action='wait')` or poll manually for background subprocess results.
- Background `terminal(background=true)` processes in cron do not return async
  completion notifications — silently monitor with `process(action='poll')` or
  redirect output to a log file and read it later.

## Error signals in `C:/Users/Stefan/AppData/Local/hermes/logs/errors.log`
Real problems in last-24h — report them:
- `state.db routing save failed: 'NoneType' object has no attribute 'execute'`
- `Persisted transcript lagged live cached history for session ... (disk=N, memory=N+1); preserving live conversation context (possible FTS write corruption)`
- `Stream ended with no finish_reason while a tool call's arguments were still incomplete`
- `Partial stream delivered before error; returning length-truncated stub`
- `Discarding chunk from superseded stream attempt`
- `Tool ... returned error: Background review denied non-whitelisted tool`
- `getaddrinfo failed` on DNS-dependent crons (key refresh, scanner)

If a state.db write error is detected, fix the underlying issue instead of silently discarding.

## Reporting rule
Produce output **only** when there are errors or zero candidates found.
Otherwise stay silent so cron delivery is suppressed.
