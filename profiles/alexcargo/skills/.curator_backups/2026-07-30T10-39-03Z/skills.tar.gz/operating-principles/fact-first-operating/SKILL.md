---
name: fact-first-operating
description: "Verify facts; self-verify bots; self-recover on failure."
---

# Fact-First Operating Principles (Stefan, 2026-07-28)

Non-negotiable working rules. They exist because Stefan caught Hermes acting on a
guessed hypothesis instead of a verified fact — which would have propagated false
assumptions into the whole agent architecture.

## HARD RULE 00 — Hypothesis MUST be confirmed by FACT before acting
- ANY hypothesis → FIRST confirm with a concrete FACT: a real API call, a real log
  line, or the agent's/bot's actual response. NOT a static test that doesn't
  replicate the runtime path, and NEVER a guess presented as truth.
- Do NOT start editing code / "fixing" until the root cause is verified by fact.
- Check all real storage locations: when looking for agent identities or files, inspect synced Google Drive paths (`C:\Users\Stefan\My Drive\...`) as well as local directories (`AppData/Local/hermes/`). Read `soul.md` / `AGENTS.md` directly for true roles (e.g. Richard Marlowe sells Navo IT products & MCP components, not physical freight).
- Anti-pattern we hit: a static `urllib` POST to Nous returned 403 → concluded
  "nous key broken, Hermes must be on OpenRouter" → started rewriting Richard's
  bot. FALSE. Hermes actually works on `tencent/hy3:free` via Nous through the
  OpenAI SDK (urllib != SDK path, so the test was invalid). Real fix = make Richard
  use the same OpenAI SDK call, not switch providers.
- Verify the right way: invoke the agent's own logic IN-PROCESS (import its module,
  call `llm_chat`/`run_agent` in the same python runtime) and read the returned
  model/base/answer. That IS the fact.

## HARD RULE 01 — Verify bots YOURSELF, do not ask the user
- Never tell Stefan "write to him and tell me what he says". You can ping the bot's
  logic directly in-process and read its response + which model it used.
- NEVER call `getUpdates` on a live Telegram bot manually — it collides with the
  bot's own long-poll and causes `409 Conflict` that silences the bot's queue
  (seen with Richard and Liz). Diagnose via in-process calls, not getUpdates.
- How: `importlib.util.spec_from_file_location` the bot's .py, call its chat fn,
  inspect returned model/base/answer. See references/bot_verification.md.

## HARD RULE 02 — Self-recovery on ANY failure
- On ANY failure (any cause): resume work yourself. First FINISH the task, then
  analyze the failure cause and fix it. Do not block waiting for Stefan.
- If 3 consecutive iterations fail to continue/finish the task → stop retrying and
  switch immediately to analyzing + fixing the failure cause.
- Example: "session storage could not be written" (state.db) → start a fresh
  session, don't halt.
- See references/self_recovery_protocol.md.

## HARD RULE 02b — Re-read your OWN output; catch self-reported errors, stream interruptions, and truncations
- Stefan caught this specifically (2026-07-28 & 2026-07-29): Hermes WROTE the self-recovery
  rule, then hit `state.db could not be written`, `Response truncated due to output length limit`, or `[This response was interrupted by a user correction.]` and did NOT apply
  it — waited for Stefan to ask "did you see the error?" or "что делать дальше?". That is a violation.
- Before sending, and ESPECIALLY after receiving any system/error signal
  (truncation, `Response truncated`, `[This response was interrupted...]`, "session storage could not be written", API 403/404/503/409 in your own
  output), RE-READ what you just produced. If it mentions an error / failure /
  "could not" / a crash or stream interruption — FIX IT IMMEDIATELY, clear stale locks if needed, page large outputs with offset/limit, and resume work without waiting for Stefan's question or asking "what to do next".
- Check all real storage locations: when looking for agent identities or files, inspect synced Google Drive paths (`C:\Users\Stefan\My Drive\...`) as well as local directories (`AppData/Local/hermes/`). Read `soul.md` / `AGENTS.md` directly for true roles (e.g. Richard Marlowe sells Navo IT products & MCP components like TrackingMCP/SchedulesMCP, not physical ocean freight; Liz's real Telegram username is `@lizharperbot`).
- Bot Watchdog & Model Fallbacks: when default models (`tencent/hy3:free`) fail with 404/403, update `.env.local` / `agent.config.json` to an active model (e.g. `gemini-3.6-flash`), clear stale `.lock` files, and verify the bot's process is running and responding via `getMe`.
- A rule you state but fail to apply to your own failure is worse than no rule.
- Concrete pattern: system error mid-turn or stream truncation → (1) note it, (2) finish/redo the
  interrupted task, (3) only then analyze root cause. Never end the turn having
  ignored a crash or truncation you just emitted.

## Trigger
Load this skill at the start of debugging, incident response, any code change to
bots/agents, or whenever you feel the urge to "fix" something you haven't yet
proven is broken.

## References
- `references/self_recovery_protocol.md` — the 3-iteration failure recovery protocol (verbatim from Stefan).
- `references/bot_verification.md` — in-process bot ping technique, getUpdates/409 warning.
- `references/pinecone_vector_memory.md` — Pinecone semantic memory technique + gotchas.
