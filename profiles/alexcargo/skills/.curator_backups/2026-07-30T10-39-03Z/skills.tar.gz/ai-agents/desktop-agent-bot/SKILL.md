---
name: desktop-agent-bot
description: >-
  Run a stdlib-only Python agent / Telegram bot locally on the user's Windows
  Desktop (the Hermes host) WITHOUT cloud deployment and WITHOUT over-engineering.
  Covers the KISS runtime (one python process), reusing Hermes' own LLM provider
  so the sub-agent needs no separate API key, single-source-of-truth system prompt,
  and the per-token single-consumer rule. Use when building/running Richard Marlowe,
  or any local agent bot the user wants alive on their machine.
---

# Desktop Agent Bot (local Python agent/Telegram bot on the Hermes host)

Pattern for running an AI agent as a **local** long-polling Python bot on the
user's Windows Desktop — where Hermes itself runs. Captured from the
Richard-Marlowe setup (2026-07-23).

## When to use
- User wants an agent (sales/support/ops) live as a Telegram bot on their machine.
- User says "make it like you" / "сделай как себе" → the bot must use the SAME
  LLM provider as Hermes, not demand a separate OpenRouter/API key.
- Avoid for: cloud-hosted agents (use Modal/VPS), or pure cron sweeps (see
  `telegram-group-sweep`).

## RUNTIME — keep it stupid simple (user-corrected, hard lesson)
A desktop bot = **ONE background python process**. That is all.
```bash
cd "<bot folder>" && python bot.py
```
Launch it with `terminal(background=true)`, not `nohup`/`setsid` (the harness
refuses shell-level backgrounding and can't track it).

**DO NOT build any of these** (all wasted 40 min in the Richard session):
- ✗ PowerShell `while($true)` daemon (`keep_richard.ps1`) — crashed, and a second
  copy spawned a SECOND update-consumer → Telegram **409 Conflict** with the manual bot.
- ✗ `Richard_Bot.vbs` Startup shortcut wrapping a daemon — fragile.
- ✗ Task Scheduler XML task (`schtasks /Create /XML`) — needs **admin** ("Access is
  denied" from this shell) and is brittle (UTF-16 encoding + `Date` format errors).

**Only** add reboot-survival (Startup-folder VBS launching `python bot.py` hidden,
OR a Task Scheduler task) if the user EXPLICITLY needs the bot alive after a laptop
reboot. Even then: no supervision loop — `python bot.py` long-poll is enough.

## LLM PROVIDER — reuse Hermes' own `nous` credentials (no separate key)
The user has NO OpenRouter key and was confused why the bot needed one ("чтобы ты
работал, я же не давал никакой ключ"). The fix: point the bot at Hermes' own
provider, read live from `auth.json`.

- `C:\Users\Stefan\AppData\Local\hermes\auth.json`
  → `providers.nous.access_token` (Bearer token, ~1777 chars)
  → `providers.nous.inference_base_url` (e.g. `https://inference-api.nousresearch.com/v1`)
- Bot endpoint: `{inference_base_url}/chat/completions`, `Authorization: Bearer {access_token}`.
- Write the token into the bot's `.env.local` as `NOUS_API_KEY` (NOT `stub-…`) — local
  file only, never print the value, never commit. This makes the bot "live" exactly
  like Hermes, no stub fallback.
- See `references/nous-credential-reuse.md` for the exact read-recipe.

## SYSTEM PROMPT — single source of truth
- The bot MUST read its persona from `system_prompt.md` (project folder), NOT a
  hardcoded string. The Richard bug: the bot had a hardcoded `RICHARD_SYSTEM` and
  silently ignored all persona edits (British humour, "don't spam") made in the md.
- `load_system_prompt()` at startup: open `system_prompt.md`, strip `#`/`>` lines,
  pass to the LLM `system` field.

## TELEGRAM — single consumer per token (shared rule)
One token's `getUpdates` → exactly ONE consumer. So:
- A realtime long-polling bot OR an hourly sweep — never both on the same token.
- User wanted **instant** answers ("отвечать тут же, не ждать hourly sweep") → chose
  REALTIME; the hourly-sweep cron was **paused** to avoid the 409. Encode this
  decision: realtime wins when the agent must converse; sweep is for batch readers.
- Privacy: BotFather `/setprivacy` → Turn off, then **remove & re-add** bot to group
  (Telegram caches privacy at join time). Without this the bot sees only @mentions.
- In groups: reply only on `@mention` or on-domain content; never on every message;
  never spam. Off-topic addressed to it: 1–2 short sentences, occasionally.

## VERIFY before declaring done
1. `python -m py_compile bot.py` — but MSYS mangles absolute paths with spaces:
   `cd` into the folder and compile the relative name.
2. `RICHARD_SELFTEST="..." python bot.py` — exercises the LLM path offline-ish.
3. Exactly ONE python process for the bot: `2 PIDs = 1 venv chain` (python →
   python uv). More than one *chain* = duplicate = 409 risk.
4. `getMe` via Bot API returns the bot username → token valid, no leak.
5. Live test: send a PM to the bot; confirm it answers (tail the bot log).

## Pitfalls (from the session)
- **Hardcoded prompt** → persona edits silently ignored. Load from md.
- **Separate OpenRouter key** → user has none; reuse `auth.json` nous token.
- **Daemon / Task Scheduler** → crashes or 409. One `python bot.py`.
- **MSYS path with spaces** → `py_compile /c/Users/.../bot.py` fails; use `cd` + relative.
- **Two consumers on one token** → 409. One bot, one mode (realtime XOR sweep).

## Support files
- `references/nous-credential-reuse.md` — exact recipe to read Hermes' `auth.json`
  `nous` token + inference URL and wire it into a sub-agent bot with no separate key.

## Overlap note (for the curator)
This skill overlaps with `ai-agents/telegram-group-sweep` (same per-token
single-consumer rule, same "minimal bot footprint" preference). They are
complementary, not duplicates: `telegram-group-sweep` covers the *hourly
diff/batch-read* pattern and its decision tree; this skill covers the *local
realtime desktop runtime* + provider-reuse + KISS. If consolidating, fold the
runtime/credential/KISS lessons here into a shared "local agent bot" umbrella and
keep `telegram-group-sweep` for the scheduled-read decision tree.
