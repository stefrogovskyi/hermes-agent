---
name: agent-discipline
description: Fact-first debugging and autonomous crash recovery.
---

# Agent Discipline

Core operating contract for autonomous sessions.

## 0 — Confirm hypotheses with FACT before action (principle 00)
Any time you form a hypothesis about why something broke or how something works:
1. **Stop before editing code/config.**
2. Verify with a real call, log, traceroute, or actual response — not by analogy or a hand-built test that does not match the real runtime path.
3. Only then apply a fix.
4. If you cannot get a fact in one shot, say so explicitly instead of inferring.

Pitfall: do not use a hand-rolled `urllib` test to prove a key is broken when the real runtime uses an SDK that may add headers/formatting. Run the same code path the runtime uses.

## 1 — Self-recover on ANY failure, no waiting for user (principle 01)
When a tool returns an error, the platform reports a storage failure, an interruption occurs (`[This response was interrupted...]`), or you see an exception in your own output:
1. **Log the failure internally** (memory/case file).
2. **Auto-resume the interrupted task immediately** — restore the goal context, log the interrupt cause, and continue from the exact checkpoint without asking the user "what next".
3. **Analyze the root cause after** the task is restored.
4. If the same task fails 3 consecutive times across retries, stop retrying and switch to root-cause analysis.
5. Never wait for the user to ask “are you done?” after you reported an error — report the resolution instead.

Pitfall: if a state-DB or session storage write fails, start fresh and regenerate the artifact rather than retrying the same write.

## 2 — Re-read your own messages/outputs (principle 02)
After you generate a response or after a system error, re-scan your own output for:
- Self-reported errors or crashes
- “I cannot do X”
- “stub”, “not implemented”, “not connected”
- Platform error notices (state.db, truncation, 429/403)

If found, act immediately — do not wait for the user to quote it back to you.

## 3 — Ask once, then act; do not loop
If you do not know something critical:
1. Ask the user **once** with a tight, scoped question.
2. On the next turn, act autonomously.
3. Do not re-ask the same question in subsequent turns.

## 4 — Truthful state reporting
Never say “fixed”, “working”, or “done” without a current, positive fact check in the same task. A previous green test does not prove current health after code or config changes.

## How to use
This skill governs debugging, crash recovery, bot operation, and any task where the user said “stop guessing, verify first” or similar. When invoked:
- Read `references/interrupt-autoresume-and-google-drive-entity-inspection.md` for specific interrupt auto-resume and Google Drive entity path inspection protocols.
- Read only the relevant case under `memory_v2/cases/` if known.
- Apply principles 00–02 in order.
- After resolution, write a case (or append to an existing one) so future sessions inherit the lesson.
