# OpenRouter Free Models — verified 2026-07-25

All 11 below were liveness-tested (HTTP 200 unless noted). All `prompt=$0 / completion=$0`.
Context = input context window; MaxOut = max output tokens (from `top_provider.max_completion_tokens`).

| # | Model (OpenRouter id) | Context | MaxOut | Status |
|---|---|---|---|---|
| 1 | nvidia/nemotron-3-ultra-550b-a55b:free | 1,000,000 | 65,536 | 200 |
| 2 | nvidia/nemotron-3-super-120b-a12b:free | 262,144 | 262,144 | 200 |
| 3 | nvidia/nemotron-3-nano-30b-a3b:free | 256,000 | — | 200 |
| 4 | google/gemma-4-31b-it:free | 262,144 | 32,768 | 429 (rate-limited) |
| 5 | google/gemma-4-26b-a4b-it:free | 262,144 | 32,768 | 429 (rate-limited) |
| 6 | openai/gpt-oss-20b:free | 131,072 | 32,768 | 200 |
| 7 | inclusionai/ling-3.0-flash:free | 262,144 | 32,768 | 200 |
| 8 | cohere/north-mini-code:free | 256,000 | 64,000 | 200 |
| 9 | poolside/laguna-m.1:free | 262,144 | 32,768 | 200 |
| 10 | nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free | 256,000 | 65,536 | 200 |
| 11 | openrouter/free | 200,000 | — | 200 |

Excluded from free set (not usable text LLMs): `lyria-3*` (music gen),
`nemotron-3.5-content-safety` (classifier), `nemotron-nano-12b-v2-vl` (vision-only).

Documented account-wide free-tier limits: ~20 requests/min, ~200 requests/day
(aggregate across all free models). Per-model token quotas: NOT published
(`per_request_limits` = null for all free models).
