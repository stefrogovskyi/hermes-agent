---
name: drive-spreadsheets-workflow
description: Google Drive and Sheets workflows and best practices.
version: 1.0.0
author: Archie Wright (Hermes Agent)
license: MIT
metadata:
  hermes:
    tags: [google-drive, google-sheets, file-management, spreadsheets, workflow]
    related_skills: [google-workspace, xlsx, hermes-agent]
---

# Drive & Spreadsheets Workflow

This skill documents best practices and efficient workflows for interacting with Google Drive and Google Sheets, focusing on native format conversions and reliable update procedures. It incorporates lessons learned from common pitfalls in file handling and API interactions.

## When to Use

Use this skill when you need to:

*   Manage spreadsheet files on Google Drive, especially converting between local formats (TSV, CSV, XLSX) and native Google Sheets.
*   Update existing spreadsheet files on Google Drive programmatically.
*   Understand best practices for efficient and reliable Google Drive and Sheets API interactions.
*   Troubleshoot issues related to large file processing or long-running tasks with `execute_code`, `terminal(background=True)`, or `cronjob` orchestration.

## Best Practices for Spreadsheets on Google Drive

When working with spreadsheets on Google Drive, prefer native Google Sheets (converted from XLSX) over TSV/CSV for direct editing and seamless integration. This avoids complex download/upload cycles and enables direct manipulation via Google's UI or Sheets API.

### Workflow to upload an Excel file (XLSX) and convert it to a native Google Sheet:

1.  **Convert your local data (e.g., TSV/CSV) to an XLSX file first.**
    (Refer to the `xlsx` skill for local CSV/TSV to XLSX conversion procedures.)

2.  **Upload the XLSX file directly with the native Google Sheet MIME type:**
    ```bash
    GAPI="python ${HERMES_HOME:-$HOME/.hermes}/skills/productivity/google-workspace/scripts/google_api.py"
    $GAPI drive upload /path/to/your_file.xlsx --name "Your Sheet Name" --mime-type application/vnd.google-apps.spreadsheet
    ```
    This command directly converts and uploads the XLSX as a Google Sheet, provided the XLSX is well-formed and compatible with Google Sheets conversion. This was the command that eventually succeeded in the conversation.

### Workflow to update an existing Google Drive file (e.g., replacing a Google Sheet with new data):

`google_api.py drive upload` creates a *new* file. To replace an existing file (e.g., updating a Google Sheet with new data from a local XLSX/CSV):

1.  **Delete the old file** using its `FILE_ID`:
    ```bash
    GAPI="python ${HERMES_HOME:-$HOME/.hermes}/skills/productivity/google-workspace/scripts/google_api.py"
    $GAPI drive delete FILE_ID
    ```
2.  **Upload the new file** (with the desired name and MIME type for conversion, if applicable):
    ```bash
    GAPI="python ${HERMES_HOME:-$HOME/.hermes}/skills/productivity/google-workspace/scripts/google_api.py"
    $GAPI drive upload /path/to/new_file.xlsx --name "Your Sheet Name" --mime-type application/vnd.google-apps.spreadsheet
    ```
    This will create a new file, effectively replacing the old one with a fresh native Google Sheet.

## Pitfalls and Considerations for Tool Usage

*   **`execute_code` for large file processing:** Avoid using `execute_code` for extensive file I/O operations (reading/writing very large files or performing long computational tasks). It can hit internal limits on output size or execution time, leading to repeated failures. For such tasks, prefer standalone Python scripts executed via `terminal` (blocking mode) or well-structured `cronjob` tasks.

*   **`terminal(background=True)` for long-running processes within current session:** Using `terminal(background=True)` from the interactive session can be problematic if the background process tries to interact with Hermes' internal gateway or if it is too long-running. For reliable, long-term background tasks or complex multi-step pipelines, always prefer `cronjob`.

*   **Orchestrating complex pipelines with `cronjob`:** For multi-step workflows involving API calls, file manipulations, and skill delegation, a `cronjob` with a detailed `prompt` that directly calls tools (like `delegate_task`) and other scripts is the most robust approach. Python scripts launched by a `cronjob` cannot directly invoke `delegate_task` or other Hermes skills; the *cronjob's prompt* must contain the high-level orchestration logic.

*   **Running Python scripts in `terminal`:** Always explicitly use `python3 /path/to/script.py` when executing Python scripts via the `terminal` tool. Simply calling `/path/to/script.py` (even if executable) can lead to syntax errors if the shell attempts to interpret it as a bash script.
